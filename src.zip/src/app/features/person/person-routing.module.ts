import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PersonComponent } from './person.component';
import { PersonListComponent } from './pages/person-list/person-list.component';
import { PersonDetailComponent } from './pages/person-detail/person-detail.component';

const routes: Routes = [
  {
    path: '',
    component: PersonComponent,
    children: [
      {
        path: 'person-list',
        component: PersonListComponent
      },
      {
        path: 'person-detail',
        component: PersonDetailComponent
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PersonRoutingModule { }
