export const environment = {
    personUrl: "http://localhost:4200/assets/persons.js"
};
