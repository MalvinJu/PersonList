[
    {
      "id": 1,
      "name": "John Doe",
      "birthday": "1993-05-15",
      "email": "john.doe@example.com",
      "occupation": "Software Engineer"
    },
    {
      "id": 2,
      "name": "Jane Smith",
      "birthday": "1995-10-20",
      "email": "jane.smith@example.com",
      "occupation": "Marketing Specialist"
    },
    {
      "id": 3,
      "name": "Michael Johnson",
      "birthday": "1988-12-03",
      "email": "michael.johnson@example.com",
      "occupation": "Teacher"
    }
  ]
  