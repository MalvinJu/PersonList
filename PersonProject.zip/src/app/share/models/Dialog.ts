export enum DialogResponse {
    Cancel = "Cancel",
    Save = "Save"
}