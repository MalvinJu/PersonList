export interface Pagination<T> {
    data: T;
    count: number
}