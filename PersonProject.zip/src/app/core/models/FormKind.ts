export enum FormKind {
    New,
    Edit,
    View
}