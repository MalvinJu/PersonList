# PersonList

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 16.1.7. There are two page in this project: person list page (show list of peson) and person detail page (show and edit person data). I spent one day to develop this project. Feel free to check it 😄.

## Packages

This project use other dependencies beside Angular:
- @angular/material for UI Component
- momentjs

## Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The application will automatically reload if you change any of the source files. 

## Person data

The person data can be found on assets folder `assets/person.js`.



